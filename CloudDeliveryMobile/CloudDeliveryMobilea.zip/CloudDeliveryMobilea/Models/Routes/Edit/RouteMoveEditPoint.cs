﻿namespace CloudDeliveryMobile.Models.Routes
{
    public class RouteMoveEditPoint
    {
        public int SourceIndex { get; set; }

        public int DestinationIndex { get; set; }
    }
}
