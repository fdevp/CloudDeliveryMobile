﻿namespace CloudDeliveryMobile.Models.Orders
{
    public class DurationDistance
    {
        public int Distance { get; set; }

        //in seconds
        public int Time { get; set; }
    }
}