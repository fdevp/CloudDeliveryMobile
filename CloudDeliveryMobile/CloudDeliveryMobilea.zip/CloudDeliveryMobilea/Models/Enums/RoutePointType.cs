﻿namespace CloudDeliveryMobile.Models.Enums
{
    public enum RoutePointType
    {
        SalePoint,
        EndPoint
    }
}
