﻿namespace CloudDeliveryMobile.Models.Enums
{
    public enum RouteStatus
    {
        Active,
        Finished
    }
}
