﻿namespace CloudDeliveryMobile.Models.Error
{
    public enum ErrorType
    {

    }
}
